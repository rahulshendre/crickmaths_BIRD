

    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">

    <link rel="stylesheet" href="assets/css/app.min.css">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>


    @media only screen and (max-width: 1000px) {

.imagenew{
    width: 100px !important;
}

}
    
li{
    font-weight: 700;
    font-size: medium;
}


    body {
        background-image: url('assets/images/bg.jpg');
        background-repeat: no-repeat;
        background-size: 100% 100%;
        height: 100%;
        padding-right: 0px;
        padding-left: 0px;
    }

    .header-layout2 {
        display: none;
    }

    .options {
      display: flex;
    justify-content: space-around;
    z-index: 9;
    position: relative;
    margin: auto;
    width: 100%;
    align-items: center;
    flex-direction: column;
    }
/*.options div:nth-child(2){
    width: 70%;
}*/
    .options_item {
        border-radius: 50%;
        width: 300px;
        height: 300px;
        text-align: center;
     

    }

    .options_item img {
        border-radius: 50%;

    }

    .options_item h2 {
        font-family: "Lucida Console", "Courier New", monospace;
        margin-top: 2%;
            color: #ffff;
    }
    .bat{
      width: 13%;
    padding: 3%;
 
}
    .bat img{
        width: 100%;
    }
    .coin { 
    padding: 3%;
      animation: coin-rotate 8s infinite;
      }
       

.a {
   opacity: 0.1;
   }
        
@keyframes coin-rotate  {  
                        0%  {
                            transform: rotateY(0deg); 
                            transform-origin: 50% 5% 0;
                            }  
                        100% {
                             transform: rotateY(360deg); 
                             transform-origin: 50% 5% 0;
                             }  
                        }

 
.blink_me {
  animation: blinker 1s linear infinite;
}

@keyframes blinker {
  50% {
    opacity: 0;
  }
}
    .row:not([class*=gx-]) {
 
    height: 100%;
}
    .card {
              background-image: url('assets/images/bg.jpg');
/*        background: purple;*/
        background-repeat: no-repeat;
        background-size: 100% 100%;
        height: 100%;
        padding-right: 0px;
        padding-left: 0px;
    
    }

 

.animate-charcter
{
   text-transform: uppercase;
  background-image: linear-gradient(
    -225deg,
    #231557 0%,
    #44107a 29%,
    #ff1361 67%,
    #fff800 100%
  );
  background-size: auto auto;
  background-clip: border-box;
  background-size: 200% auto;
  color: #ffff;
  background-clip: text;
  text-fill-color: transparent;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: textclip 80s linear infinite;
  display: inline-block;
   
}

@keyframes textclip {
  to {
    background-position: 200% center;
  }
}
.mcq{

    background: transparent;
}

  .mcq-option {
      opacity: 0; /* Initial opacity set to 0 */
      animation: fadeIn ease-in-out 0.5s forwards; /* Animation definition */
   width: 45%;
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(-10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    .radio span{
        color: #ffff;
    }

    .dropdown {
    margin-top: 10px;
}

.dropdown-btn {
    background-color: #000000;
    color: #fff;
    padding: 10px;
    width: 200px;
    cursor: pointer;
    z-index: 10;
    overflow: hidden;
  -webkit-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

.dropdown-area {
    width: 220px;
    transform: translateY(-35px);
    opacity: 0;
    pointer-events: none;
    z-index: -1;
}

.dropdown-area ul {
    padding: 0;
    list-style: none;
}

.dropdown-area ul li {
    border-bottom: 1px solid #eee;
    padding: 10px;
    cursor: pointer;
    transition: .3s;
}

.dropdown-area ul li:nth-child(1) {
    background-color: #fff;
    margin-top: -20px;
    transition: .3s;
}

.dropdown-area ul li:nth-child(2) {
    background-color: #aaaaaa;
    margin-top: -40px;
    transition: .5s;
}

.dropdown-area ul li:nth-child(3) {
    background-color: #828282;
    margin-top: -40px;
    transition: .6s;
    color: #fff;
}

.dropdown-area ul li:nth-child(4) {
    background-color: #656565;
    margin-top: -40px;
    transition: .7s;
    color: #fff;
}

.dropdown-area ul li:nth-child(5) {
    background-color: #484848;
    margin-top: -40px;
    transition: .8s;
    color: #fff;
}


.activeDropArea {
    opacity: 1;
    pointer-events: all;
    transform: translateY(-15px);
}

.activeDropArea ul li:nth-child(1),.activeDropArea ul li:nth-child(2),.activeDropArea ul li:nth-child(3),.activeDropArea ul li:nth-child(4),.activeDropArea ul li:nth-child(5) {
    margin-top: 0;
}
.main-menu ul li.menu-item-has-children>a:after {
    content: "";
}
.main-menu ul.sub-menu, .main-menu ul.mega-menu {
    background-color: transparent;  
    color: white;
        border-bottom: 0px ;
}
.main-menu ul.sub-menu:before {
  
    width: 0px;
}
.main-menu ul.sub-menu li a:before {
    content: none;
}
.border {
    border: 0px solid #dee2e6!important;
}
.question-title h5 {
 border: 0px solid;
    }
    nav ul{
      display: flex;
    
    align-items: center;
    justify-content: space-between;
}


/*=======================================*/
.marquee {
  overflow: hidden;
  mask-image: linear-gradient(to right, rgba(0, 0, 0, 0%) 0%, #000 var(--marquee-fade-edges), #000 calc(100% - var(--marquee-fade-edges)), rgba(0, 0, 0, 0%) 100%);
  
  &,
  > div {
    display: flex;
    white-space: nowrap;
    gap: 30px;
  }
 
  > div {
    animation: animate-marquee var(--marquee-speed) infinite linear;
    transition: var(--marquee-hover-transition-speed) margin-left ease-out;
    will-change: transform, margin-left;
  }
  
  &:hover > div {
    animation-play-state: paused;
    margin-left: var(--marquee-hover-offset);
  }
}
 .options a {
        text-align: center;
     }  
@keyframes animate-marquee {
  0% {
    transform: translateX(0%) translateZ(0);
  }
  100% {
    transform: translateX(-100%) translateZ(0);
  }
}



</style>


  <nav class="main-menu menu-style2">
    <ul>
                           <li style="margin-left: 2%;"> 
                            <a type="button" href="{{config('app.baseURL')}}">
                                <i class="fa fa-power-off" style="font-size:30px;color: white;" aria-hidden="true">
                                    
                                </i>
                            </a>
                        </li>
                            </ul>
                        </nav>
                          <div class="options">
<div class="bat">
                   
                    <div class="coin"> <img src="assets/images/bat2.png" alt=""></div>
                </div>
          <a id="startbtn" href="after-start">
              <div class="start">
                   

                    <img id="imgmobile" class="imagenew" src="assets/images/start2.png" alt="">
                        <h2 class="blink_me">START</h2>
                 
                
                </div>
                </a>
            </div>
                 
<div class="marquee">


    <marquee><h6 style="color:#ffff;">Pad up, embrace the challenge. Join us in this unique journey where learning meets excitement, and every correct answer takes you closer to victory. Are you up for the challenge? Let the tournament begin!</h6></marquee>
  
</div>
        

    
<script src="assets/js/vendor/jquery-3.6.0.min.js"></script>




